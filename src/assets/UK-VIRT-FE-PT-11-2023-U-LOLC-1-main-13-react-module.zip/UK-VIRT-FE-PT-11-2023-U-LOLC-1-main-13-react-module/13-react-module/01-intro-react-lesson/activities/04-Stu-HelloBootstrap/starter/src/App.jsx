import React from "react";

function App() {
  return <p>Render Bootstrap components here</p>;
}

export default App;
