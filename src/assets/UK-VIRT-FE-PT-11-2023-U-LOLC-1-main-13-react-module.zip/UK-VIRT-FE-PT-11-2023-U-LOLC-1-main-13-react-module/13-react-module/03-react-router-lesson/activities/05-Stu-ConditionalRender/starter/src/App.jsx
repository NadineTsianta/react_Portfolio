import React from "react";
import PortfolioContainer from "./components/PortfolioContainer";

function App() {
  return <PortfolioContainer />;
}

export default App;
