import React from "react";
import HelloDiv from "./components/HelloDiv";

function App() {
  return <HelloDiv />;
}

export default App;
